export const useAltEndpoint: boolean = false;

export const baseUrl = useAltEndpoint ? 'https://rips.cc' : 'https://ee3.me';

export const username = '_sf_';

export const password = 'defonotscraping';

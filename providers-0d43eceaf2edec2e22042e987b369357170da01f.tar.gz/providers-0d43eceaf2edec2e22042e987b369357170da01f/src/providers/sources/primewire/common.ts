export const primewireBase = 'https://www.primewire.tf';
export const primewireApiKey = atob('bHpRUHNYU0tjRw==');
